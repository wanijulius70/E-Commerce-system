
<!DOCTYPE html>
<html lang = "en">
	<head>
		<meta charset = "UTF-8" name = "viewport" content = "width-device=width, initial-scale=1" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<title>Health system</title>
	</head>
 



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Home |  </title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

        <style>
            .body {
             background-color: blue;
            }
            </style>
    </head>
    <body>
         
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand ps-3" href="index.php">HEALTH SYSTEM</a>
          
        </nav>
        <div id="layoutSidenav">
       
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4"></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li></div>
                            
                            <li>     <a href="http://localhost/Julio/birth_death.php">Birth & Death</a></li>
                            <div class="col-lg-12">
                    <center><h2 class = "text-primary">Antinental Card (A.C)</h2></center>
					<hr>
				<div>
    <style>
        .body{
            background-image: (assets/img/one.jpg)
        }
        .wrapper{
            width: 60%;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
<form>
        
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5 mb-3 clearfix">
                             </div>
                    <?php
                    // Include config file
                    require_once "config.php";
                    
                    // Attempt select query execution
                    $sql = "SELECT * FROM antinental";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo '<table class="table table-bordered table-striped">';
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>Id</th>";
                                        echo "<th>health_facility</th>";
                                        echo "<th>district</th>";
                                        echo "<th>village</th>";
                                        echo "<th>names</th>";
                                        echo "<th>date</th>";
                                        echo "<th>status</th>";
                                        echo "<th>cardno</th>";
                                        echo "<th>ages</th>";
                                        echo "<th>history</th>";
                                        echo "<th>no</th>";
                                        echo "<th>name</th>";
                                        echo "<th>age</th>";
                                        echo "<th>period</th>";
                                        echo "<th>sex</th>";
                                        echo "<th>live</th>";
                                        echo "<th>death</th>";
                                    
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['health_facility'] . "</td>";
                                        echo "<td>" . $row['district'] . "</td>";
                                        echo "<td>" . $row['village'] . "</td>";
                                        echo "<td>" . $row['names'] . "</td>";
                                        echo "<td>" . $row['date'] . "</td>";
                                        echo "<td>" . $row['status'] . "</td>";
                                        echo "<td>" . $row['cardno'] . "</td>";
                                        echo "<td>" . $row['ages'] . "</td>";
                                        echo "<td>" . $row['history'] . "</td>";
                                        echo "<td>" . $row['no'] . "</td>";
                                        echo "<td>" . $row['name'] . "</td>";
                                        echo "<td>" . $row['age'] . "</td>";
                                        echo "<td>" . $row['period'] . "</td>";
                                        echo "<td>" . $row['sex'] . "</td>";
                                        echo "<td>" . $row['live'] . "</td>";
                                        echo "<td>" . $row['death'] . "</td>";     
                                           
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                        }
                    } else{
                        echo "Oops! Something went wrong. Please try again later.";
                    }
 
                    // Close connection
                    mysqli_close($link);
                    ?>
                </div>
            </div>        
        </div>
          
      </form>
            
           <center><br><br><br>
            By Julio!
            </a></center><br><br>
              </table>
    <div class="row">
      <div class >              
      
</body>
</html>