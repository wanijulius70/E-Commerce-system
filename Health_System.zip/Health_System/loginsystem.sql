-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2022 at 09:10 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loginsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '1'),
(2, 'admin', '5c428d8875d2948607f3e3fe134d71b4'),
(3, 'wanijulius@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(100) NOT NULL,
  `officename` varchar(100) NOT NULL,
  `officelocation` varchar(100) NOT NULL,
  `number` varchar(10) NOT NULL,
  `phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `content_table`
--

CREATE TABLE `content_table` (
  `id` int(11) NOT NULL,
  `USERNAME` varchar(25) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `OFFICE_NAME` varchar(25) NOT NULL,
  `E-MAIL` varchar(25) NOT NULL,
  `LOCATION` varchar(20) NOT NULL,
  `NUMBER` int(11) NOT NULL,
  `PHONE_NUMBER` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `content_table`
--

INSERT INTO `content_table` (`id`, `USERNAME`, `PASSWORD`, `OFFICE_NAME`, `E-MAIL`, `LOCATION`, `NUMBER`, `PHONE_NUMBER`) VALUES
(1, 'A84576', 'welcome', 'UIS', 'wanijulius@gmail.com', 'Hamsmukasa', 817, ''),
(3, 'A84987', 'pretty', 'Academics', 'tannet120@gmail.com', 'Counseling Dpt', 818, ''),
(4, 'A8809', 'beauty', 'Standards', 'ttonyt23@yahoo.com', 'Vice Chansellor', 819, ''),
(5, 'A8596', 'christian', 'APC', 'jamesd100@gmail.com', 'Bishop Tarker', 820, ''),
(6, 'A98988', 'pronald', 'Library', 'suetukube@hotmail.com', 'UCU Library', 821, ''),
(7, 'A98954', 'suzaana', 'Registra', 'speter120@hotmail.com', 'Academics', 822, ''),
(8, 'A90987', 'rachael', 'Accounts', 'erachael25@gmail.com', 'Counseling Dpt', 823, '');

-- --------------------------------------------------------

--
-- Table structure for table `new_record`
--

CREATE TABLE `new_record` (
  `id` int(50) NOT NULL,
  `trn_date` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(10) NOT NULL,
  `submittedby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `contactno` varchar(11) DEFAULT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `contactno`, `posting_date`) VALUES
(2, 'wanijulius@gmail.com', 'wanijulius70@gmail.com', '123', NULL, '2022-05-27 11:38:41'),
(3, 'reachel20@gmail.com', 'breachel199@hotmail.com', '1234', NULL, '2022-05-27 11:38:41'),
(13, 'Anuj', 'phpgurukulteam@gmail.com', 'Test@123', '1234567890', '2021-08-09 18:30:00'),
(15, 'wanijulius@gmail.com', 'wanijulius70@gmail.com', '123', NULL, '2022-05-30 06:28:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content_table`
--
ALTER TABLE `content_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_record`
--
ALTER TABLE `new_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `content_table`
--
ALTER TABLE `content_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `new_record`
--
ALTER TABLE `new_record`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
