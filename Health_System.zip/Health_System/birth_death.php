
<!DOCTYPE html>
<html lang = "en">
	<head>
		<meta charset = "UTF-8" name = "viewport" content = "width-device=width, initial-scale=1" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<title>Health system</title>
	</head>
 



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Home |  </title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

        <style>
            .body {
             background-color: blue;
            }
            </style>
    </head>
    <body>
         
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand ps-3" href="index.php">HEALTH SYSTEM</a>
          
        </nav>
        <div id="layoutSidenav">
       
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4"></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li></div>
                            <li><a href="http://localhost/Julio/index.php">Back to Table</a> </li>
                            <div class="col-lg-12">
                    <center><h2 class = "text-primary">Birth & Death Rates (B.D)</h2></center>
					<hr>
				<div>
<?php
$servername = "localhost";
$username = "root";
$password = " ";
$dbname = "student";

// Create connection
$conn = new mysqli("localhost", "root", "", "student");
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, live, death FROM antinental ";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
       
    echo "id: " . $row["id"]. " Live: " . $row["live"].   "death: " . $row["death"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?> 

<center>

<div class = "form-group"><br>
<center>By Julio!
 
</center>