<?php session_start(); 
include('conn.php');
// Code for login 
if(isset($_POST['login']))
{
    $health_facility=$_POST['health_facility'];
	$district=$_POST['district'];
	$village=$_POST['village'];
    $names=$_POST['names'];
    $date=$_POST['date'];
    $status=$_POST['status'];
	$cardno=$_POST['cardno'];
	$ages=$_POST['ages'];
    $history=$_POST['history'];
    $no=$_POST['no'];
    $name=$_POST['name'];
	$age=$_POST['age'];
	$period=$_POST['period'];
    $sex=$_POST['sex'];
    $live=$_POST['live'];
    $death=$_POST['death'];
$ret= mysqli_query($con,"SELECT id,health_facility FROM antinental WHERE health_facility='$health_facility' and district='$district'");
$num=mysqli_fetch_array($ret);
if($num>0)
{

$_SESSION['health_facility']=$num['health_facility'];
$_SESSION['district']=$num['district'];
$_SESSION['village']=$num['village'];
$_SESSION['names']=$num['names'];
$_SESSION['date']=$num['date'];
$_SESSION['status']=$num['status'];
$_SESSION['cardno']=$num['cardno'];
$_SESSION['ages']=$num['ages'];
$_SESSION['history']=$num['history'];
$_SESSION['no']=$num['no'];
$_SESSION['name']=$num['name'];
$_SESSION['age']=$num['age'];
$_SESSION['period']=$num['period'];
$_SESSION['sex']=$num['sex'];
$_SESSION['live']=$num['live'];
$_SESSION['death']=$num['death'];
header("location:welcome.php");

}
else
{
echo "<script>alert('Invalid email or password');</script>";
}
}
?>


<?php
header("Location: http://localhost/Julio/index.php");
exit();
?>
