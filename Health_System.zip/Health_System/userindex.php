<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Syetem</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .body{
            background-image: (assets/img/one.jpg)
        }
        .wrapper{
            width: 60%;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }
    </style>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
<form>
        
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-5 mb-3 clearfix">
                        <h2 class="pull-left">Antinental Card</h2>
                                           </div>
                    <?php
                    include('conn.php');
                    $sql = "SELECT * FROM antinental";
                   
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo '<table class="table table-bordered table-striped">';
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>Id</th>";
                                        echo "<th>health_facility</th>";
                                        echo "<th>district</th>";
                                        echo "<th>village</th>";
                                        echo "<th>names</th>";
                                        echo "<th>date</th>";
                                        echo "<th>status</th>";
                                        echo "<th>cardno</th>";
                                        echo "<th>ages</th>";
                                        echo "<th>history</th>";
                                        echo "<th>no</th>";
                                        echo "<th>name</th>";
                                        echo "<th>age</th>";
                                        echo "<th>period</th>";
                                        echo "<th>sex</th>";
                                        echo "<th>live</th>";
                                        echo "<th>death</th>";
                                    
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['health_facility'] . "</td>";
                                        echo "<td>" . $row['district'] . "</td>";
                                        echo "<td>" . $row['village'] . "</td>";
                                        echo "<td>" . $row['names'] . "</td>";
                                        echo "<td>" . $row['date'] . "</td>";
                                        echo "<td>" . $row['status'] . "</td>";
                                        echo "<td>" . $row['cardno'] . "</td>";
                                        echo "<td>" . $row['ages'] . "</td>";
                                        echo "<td>" . $row['history'] . "</td>";
                                        echo "<td>" . $row['no'] . "</td>";
                                        echo "<td>" . $row['name'] . "</td>";
                                        echo "<td>" . $row['age'] . "</td>";
                                        echo "<td>" . $row['period'] . "</td>";
                                        echo "<td>" . $row['sex'] . "</td>";
                                        echo "<td>" . $row['live'] . "</td>";
                                        echo "<td>" . $row['death'] . "</td>";     
                                           
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                        }
                    } else{
                        echo "Oops! Something went wrong. Please try again later.";
                    }
 
                    // Close connection
                    mysqli_close($link);
                    ?>
                </div>
            </div>        
        </div>

        <center>
           
      </form>
            </a></center><br><br>

    <center>
            BY JULIE-JAY TECH!
            </a></center><br><br>
          
           
              </table>
    <div class="row">
      <div class >              
      
</body>
</html>