
<!DOCTYPE html>
<html lang = "en">
	<head>
		<meta charset = "UTF-8" name = "viewport" content = "width-device=width, initial-scale=1" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<title>Health system</title>
	</head>
 



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Home |  </title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

        <style>
            .body {
             background-color: blue;
            }
            </style>
    </head>
    <body>
         
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand ps-3" href="index.php">HEALTH SYSTEM</a>
          
        </nav>
        <div id="layoutSidenav">
       
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4"></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <div class="col-lg-12">
                    <center><h2 class = "text-primary">Birth & Death Rates (B.D)</h2></center>
					<hr>
				<div>
        <style>
            .body {
             background-color: blue;
            }
            </style>
    </head>
    <body>
         
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <a class="navbar-brand ps-3" href="index.php">HEALTH SYSTEM</a>
          
        </nav>
        <div id="layoutSidenav">
       
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4"></h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <div class="col-lg-12">
                    <center><h2 class = "text-primary">Antinental Card (A.C)</h2></center>
					<hr>
				<div>
                <form action="user.php" method="POST">
                                        
					<div class = "form-inline">
						<div class = "form-group">
							<label>Health facility Name:</label>
							<input type  = "text" id = "health_facility" class = "form-control">
						</div><br>
						<div class = "form-group">
							<label>County_District:</label>
							<input type  = "text" id = "district" class = "form-control">
					

						<label>Village:</label>
							<input type  = "text" id = "village" class = "form-control">
						</div><br>
						<div class = "form-group">
							<label>Name:</label>
							<input type  = "text" id = "names" class = "form-control">
						</div><br>
                        <div class = "form-group">
							<label>Date:</label>
							<input type  = "text" id = "date" class = "form-control">
						</div><br>
						<div class = "form-group">
							<label>cardno:</label>
							<input type  = "text" id = "cardno" class = "form-control">
						</div><br>

						<label>Marital Status:</label>
							<input type  = "text" id = "status" class = "form-control">
						</div><br>
						<div class = "form-group">
							<label>Age:</label>
							<input type  = "text" id = "ages" class = "form-control">
						</div><br>
                        <div class = "form-group">
							<label>Past Health History:</label>
							<input type  = "text" id = "history" class = "form-control">
						</div><br>
                        </ol>
        <div class="row" >
                            
        <div class="col-lg-12">
                    <center><h2 class = "text-primary">More Details</h2></center>
					<hr>
				<div>

						<div class = "form-group">
							<label>Pregnancyno:</label>
							<input type  = "text" id = "no" class = "form-control">
						</div><br>

						<label>Mother's Name:</label>
							<input type  = "text" id = "name" class = "form-control">
						</div><br>
						<div class = "form-group">
							<label>Age:</label>
							<input type  = "text" id = "age" class = "form-control">
						</div><br>
                        <div class = "form-group">
							<label>Period_weeks:</label>
							<input type  = "text" id = "period" class = "form-control">
						</div><br>
						<div class = "form-group">
							<label>Sex:</label><br>
							<input type  = "text" id = "sex" class = "form-control">
						</div><br>

						<label>Live_Birth:</label>
							<input type  = "text" id = "live" class = "form-control">
						</div><br>
						<div class = "form-group">
							<label>Death_Birth:</label>
							<input type  = "text" id = "death" class = "form-control">
						</div><br>
						<div class = "form-group"><br>
							<div class = "d-grid"><button type="submit" class = "btn btn-primary btn-block" name="submit">Submit</button>
						</div><br>
                          </form>
				</div>
                </div>
  
   <?php include_once('includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
 
    </body>
</html>
 
 
  