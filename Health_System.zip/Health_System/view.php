<?php
	include('conn.php');
	if(isset($_POST['show'])){
		?>
		<table class = "table table-bordered alert-warning ">
			<thead>
				<th>health_facility</th>
				<th>district</th>
				<th>village</th>
				<th>names</th>
				<th>date</th>
				<th>status</th>
				<th>cardno</th>
				<th>ages</th>
				<th>history</th>
				<th>no</th>
				<th>name</th>
				<th>age</th>
				<th>period</th>
				<th>sex</th>
				<th>live</th>
				<th>death</th>
				</thead>
				<tbody>
					<?php
						$quser=mysqli_query($conn,"select * from `antinental`");
						while($urow=mysqli_fetch_array($quser)){
							?>
								<tr>
									<td><?php echo $urow['health_facility']; ?></td>
									<td><?php echo $urow['district']; ?></td>
									<td><?php echo $urow['village']; ?></td>
									<td><?php echo $urow['names']; ?></td>
									<td><?php echo $urow['date']; ?></td>
									<td><?php echo $urow['status']; ?></td>
									<td><?php echo $urow['cardno']; ?></td>
									<td><?php echo $urow['ages']; ?></td>
									<td><?php echo $urow['history']; ?></td>
									<td><?php echo $urow['no']; ?></td>
									<td><?php echo $urow['name']; ?></td>
									<td><?php echo $urow['age']; ?></td>
									<td><?php echo $urow['period']; ?></td>
									<td><?php echo $urow['sex']; ?></td>
									<td><?php echo $urow['live']; ?></td>
									<td><?php echo $urow['death']; ?></td>
									<td><button class="btn btn-success" data-toggle="modal" data-target="<?php echo $urow['userid']; ?>"><span class = "glyphicon glyphicon-pencil"></span> Edit</button> | <button class="btn btn-danger delete" value="<?php echo $urow['userid']; ?>"><span class = "glyphicon glyphicon-trash"></span> Delete</button>
									<?php include('edit_modal.php'); ?>
									</td>
								</tr>
							<?php
						}
					
					?>
				</tbody>
			</table>
		<?php
	}

?>