<?php
$host="localhost";
$user="root";
$pass="";
$db="content";

$con=mysqli_connect($host,$user,$pass,$db);

if ($con) {
    echo "ok";
}
else
{
    echo "DB not connected"
}

?>