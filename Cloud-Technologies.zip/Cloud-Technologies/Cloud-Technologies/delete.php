<?php
	$id=$_GET['number'];
	include('db.php');
	mysqli_query($conn,"delete from `content_table` where usernumber='$number'");
	header('location:index.php');
?>