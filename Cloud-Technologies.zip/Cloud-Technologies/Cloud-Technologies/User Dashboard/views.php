<!DOCTYPE html>
<html>
<head>
<title>Content Table</title>
<style>
table {
border-collapse: collapse;
width: 80%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>
<th>Number</th>
<th>Officename</th>
<th>Officelocation</th>
<th>Phone</th>
 	</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "content");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT number, officename, officelocation, phone FROM content_table";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["number"]. "</td><td>" . $row["officename"] . "</td><td>"
. $row["officelocation"]. "</td></tr>" . $row["phone"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
</body>
</html>