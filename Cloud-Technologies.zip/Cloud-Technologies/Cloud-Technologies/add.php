<!DOCTYPE html>
<html>
<head>
<title>Add</title>
</head>
<body>
	<div>
		<form method="POST" action="add.php">
			<label>Number:</label><input type="text" name="number">
			<label>Officename:</label><input type="text" name="officename">
			<label>Officelocation:</label><input type="text" name="officelocation">
			<label>phone:</label><input type="text" name="phone">
			<input type="submit" name="add">
		</form>
	</div>
	<br>
	<div>
		<table border="1">
			<thead>
				<th>Number</th>
				<th>Officename</th>
				<th>Officelocation</th>
				<th>Phone</th>
				<th></th>
			</thead>
			<tbody>
				<?php
					include('db.php');
					$query=mysqli_query($conn,"select * from `content_table`");
					while($row=mysqli_fetch_array($query)){
						?>
						<tr>
							<td><?php echo $row['number']; ?></td>
							<td><?php echo $row['officename']; ?></td>
							<td><?php echo $row['officelocation']; ?></td>
							<td><?php echo $row['phone']; ?></td>
							<td>
								<a href="edit.php?id=<?php echo $row['number']; ?>">Edit</a>
								<a href="delete.php?id=<?php echo $row['number']; ?>">Delete</a>
								<a href="delete.php?id=<?php echo $row['number']; ?>">Add</a>
							</td>
						</tr>
						<?php
					}
				?>
			</tbody>
		</table>
	</div>
</body>
</html>