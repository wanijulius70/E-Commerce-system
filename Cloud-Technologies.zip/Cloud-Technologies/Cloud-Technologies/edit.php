<?php
	include('db.php');
	$number=$_GET['number'];
 
	$number=$_POST['number'];
	$officename=$_POST['officename'];
$officelocation=$_POST['officelocation'];
$phone=$_POST['phone'];
 
	mysqli_query($conn,"update `content_table` set number='$number', officename='$officename', officelocation='$officelocation', phone='$phone' where usernumber='$number'");
	header('location:index.php');
?>