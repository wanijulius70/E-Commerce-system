<?php session_start(); 
include_once('includes/config.php');
// Code for login 
if(isset($_POST['login']))
{
$password=$_POST['password'];
$password=$password;
$username=$_POST['username'];
$result= mysqli_query($con,"SELECT id,username FROM users WHERE username='$username' and password='$password'");
$num=mysqli_fetch_array($result);
if($num>0)
{

$_SESSION['id']=$num['id'];
$_SESSION['name']=$num['username'];
header("location:welcome.php");

}
else
{
echo "<script>alert('Invalid username or password');</script>";
}
}
?>

<?php
header("Location: http://localhost/Cloud-Tech/Cloud-Tech/Admin%20Dashboard/dashboard.php");
exit();
?>
