<?php
include("db.php");
if(isset($_POST['Submit'])) {    
$number = $_POST['number'];
$officename = $_POST['officename'];
$officelocation = $_POST['officelocation'];
$phone = $_POST['phone'];
        
if(empty($number) || empty($officename) || empty($officelocation) || empty($phone)) {                
if(empty($number)) {
echo "Product Name field is empty ";
}
if(empty($officename)) {
echo " Product Code field is empty ";
}
if(empty($officelocation)) {
echo " Product Price  field is empty ";
}
if(empty($phone)) {
    echo " Product Price  field is empty ";
    }

$result = mysqli_query($cser, "INSERT INTO content_table (number,officename,officelocation,phone) VALUES('$number','$officename','$officelocation', '$phone')");
        
echo " Data added successfully. ";
 
$_SESSION['number']=$num['number'];
$_SESSION['officename']=$num['officename'];
$_SESSION['officelocation']=$num['officelocation'];
$_SESSION['phone']=$num['phone'];
header("location:welcome.php");

}
}
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>User Login | JULIO-TECH SOLUTIONS SYSTEM</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    
        <body>
<?php if (isset($_SESSION['message'])): ?>
	<div class="msg">
		<?php 
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">

<div class="card-header">
<h2 align="center">JULIO-TECH SOLUTIONS SYSTEM</h2>
<hr />
    <h3 class="text-center font-weight-light my-4">Content</h3></div>
                                    <div class="card-body">
                                        
                                        <form method="post">

 Number: <input type="number" name="number" id="number" ><br><br>
Officename: <input type="text" name="officename" id="officename" ><br><br>
Officelocation: <input type="text" name="officelocation" id="officelocation"><br><br>
Phone: <input type="text" name="phone"id="phone"><br><br>
<input type="Submit">
</form>

</body>
</html>
<?php include('includes/footer.php');?>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>


