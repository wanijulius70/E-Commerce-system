<?php session_start(); 
include('includes/config.php');
// Code for login 
if(isset($_POST['login']))
{
$password=$_POST['password'];
$dec_password=$password;
$email=$_POST['email'];
$ret= mysqli_query($con,"SELECT id,email FROM users WHERE email='$email' and password='$password'");
$num=mysqli_fetch_array($ret);
if($num>0)
{

$_SESSION['id']=$num['id'];
$_SESSION['name']=$num['email'];
header("location:welcome.php");

}
else
{
echo "<script>alert('Invalid email or password');</script>";
}
}
?>


<?php
header("Location: http://localhost/Cloud-Tech/Cloud-Tech/User%20Dashboard/dashboard.html");
exit();
?>
